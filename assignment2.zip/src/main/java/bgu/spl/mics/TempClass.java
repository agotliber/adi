package bgu.spl.mics;

/**
 * Created by Shai on 22/11/2018.
 */
public class TempClass {
    public int square (int x){
        return x*x;
    }
}
