package bgu.spl.mics;

import bgu.spl.mics.example.messages.ExampleBroadcast;

import javax.management.openmbean.OpenMBeanConstructorInfo;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

/**
 * The {@link MessageBusImpl class is the implementation of the MessageBus interface.
 * Write your implementation here!
 * Only private fields and methods can be added to this class.
 */
public class MessageBusImpl implements MessageBus {

	private Vector<MicroService> microServiceVector = new Vector<>(); // this is a vector of all of the Micro Services.
	private Vector<MessageQueue> microServiceQueueVector = new Vector<>();// this is a vector of the queues of the Micro Services.
	private Vector<Vector<Class>> subscribedEvents = new Vector<>(); // Vector of the events Micro Service is subscribed to.
	private Vector<Vector<Class>> subscribedBroadcasts = new Vector<>(); // Vector of the broadcasts Micro Service is subscribed to.
	private Vector<Thread> threadVector = new Vector<>(); // Vector for the Thread of each Micro-Service.
	private HashMap<Message,Future> messageFutureHashMap = new HashMap<Message,Future>();

	private static MessageBusImpl messageBus = null; // Singleton.

	private MessageBusImpl() { // Constructor
		//initialization code.....
	}

	public static MessageBusImpl getMessageBus() {
		if (messageBus == null)
			messageBus = new MessageBusImpl();
		return messageBus;
	}

	public <T> void subscribeEvent(Class<? extends Event<T>> type, MicroService m) {
		int indexOfMicroService = microServiceVector.indexOf(m);
		subscribedEvents.get(indexOfMicroService).add(type);
	}

	public void subscribeBroadcast(Class<? extends Broadcast> type, MicroService m) {
		int indexOfMicroService = microServiceVector.indexOf(m);
		subscribedBroadcasts.get(indexOfMicroService).add(type);
	}

	@Override
	public <T> void complete(Event<T> e, T result) {
		Future future = messageFutureHashMap.get(e);
		future.resolve(result);
	}

	public void sendBroadcast(Broadcast b) {
		Iterator subscribedBroadcastsIterator = subscribedBroadcasts.iterator();
		int indexOfMicroService = 0;
		while (subscribedBroadcastsIterator.hasNext()) {
			if (((Vector) subscribedBroadcastsIterator.next()).contains(b.getClass()))
				microServiceQueueVector.get(indexOfMicroService).enqueue(b);
			indexOfMicroService++;
		}
	}

	@Override
	public <T> Future<T> sendEvent(Event<T> e) {
		Future future = new Future();
		messageFutureHashMap.put(e,future);
		microServiceQueueVector.get(0).enqueue(e);
		return future;
	}

	public void register(MicroService m) {
		this.microServiceVector.add(m); // we add the microService to the vector of Micro-Services.
		this.microServiceQueueVector.add(new MessageQueue()); // and we add to queue of m to the same index.
		this.subscribedEvents.add(new Vector<Class>());
		this.subscribedBroadcasts.add(new Vector<Class>());
		this.threadVector.add(new Thread(m));

		//threadVector.get(microServiceVector.indexOf(m)).start(); // start the Thread.

	}

	@Override
	public void unregister(MicroService m) {
		// TODO Auto-generated method stub

	}

	@Override
	public Message awaitMessage(MicroService m) throws InterruptedException {
		if (microServiceVector.contains(m)) { // If TRUE, then m was registered.
			int indexOfMicroService = microServiceVector.indexOf(m); // TODO: right now we assume the queue is not empty. but that is not always the case.
			while ((microServiceQueueVector.get(indexOfMicroService)).peek() == null) {
				Thread.sleep(1000);
				System.out.println("Checking if there is any message in the message queue, if not waiting 1 Second");
			}
			return ((Message) (microServiceQueueVector.get(indexOfMicroService).dequeue()));
		} else {
			throw new InterruptedException("Micro-Service was not registered.");
		}
	}

}